execute as @a[scores={acta_deaths=1..}] at @s run title @a title [{"text":"☠ ","color":"dark_red","bold":true},{"selector":"@s","color":"red","bold":true},{"text":" HA MUERTO ☠","color":"dark_red","bold":true}]
execute as @a[scores={acta_deaths=1..}] run title @a subtitle {"text":"LA RUN HA TERMINADO","color":"red","bold":true}
execute as @a[scores={acta_deaths=1..}] at @s run playsound acta:death master @a ~ ~ ~ 1 1
scoreboard players set @a[scores={acta_deaths=1..}] acta_deaths 0
